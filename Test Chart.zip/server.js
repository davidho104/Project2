//Server file

let app = require("express")();
let http = require("http").Server(app);
let io = require("socket.io")(http);
let mysql = require("mysql");

let connection = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "righter",
    database: "automentor_db"
})

function getData(callback) {
    // connection.query("SELECT user_id, quiz_id, score FROM results", function (err, rows) {
    //     console.log(err);
    //     console.log(rows);
    //     return callback(err, rows);
    // })

    let rows1 = {};
    let rows2 = {};

    connection.query("SELECT users.username, SUM(results.score) FROM results JOIN users ON results.user_id = users.id GROUP BY users.username", function (err, rows1a) {
        console.log(err);
        console.log(rows1a);
        rows1 = rows1a;
        connection.query("SELECT quizzes.id, SUM(results.score) FROM results JOIN quizzes ON results.quiz_id = quizzes.id GROUP BY quizzes.id", function (err, rows2a) {
            console.log("second data");
            console.log(err);
            console.log(rows2a);
            rows2 = rows2a;
            return callback(rows1, rows2);
        })
    })
}

io.on("connection", function (socket){
    socket.on("GET", function (data) {
        getData(function (rows1, rows2) {
            console.log("test");
            console.log(rows1);
            console.log(rows2);
            socket.emit("serverSent", rows1);
            socket.emit("serverSent2", rows2);
        })
    })
})

app.get("/", function (req, res){
    res.sendFile(__dirname + '/index.html');
})

http.listen(3000, function () {
    console.log("Listening to *3000");
})