//Server file

// Dependencies
// =============================================================
let express = require("express");
let app = express();
let http = require("http").Server(app);
//let io = require("socket.io")(http);
let mysql = require("mysql");
let path = require("path");

// ==============================================================================
// EXPRESS CONFIGURATION
// This sets up the basic properties for our express server
// ==============================================================================

let connection = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "righter",
    database: "automentor_db"
})

// Sets up the Express App
// =============================================================


// Sets an initial port. We"ll use this later in our listener
let PORT = process.env.PORT || 3000;

// Sets up the Express app to handle data parsing
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// ===============================================================================
// ROUTING
// ===============================================================================

// Basic route that sends the user first to the AJAX Page
app.get("/", function (req, res) {
    res.sendFile(path.join(__dirname, "/index.html"));
})

// Function to collect data for FIRST Graph
function getData(callback) {
    let rows1 = {};
    connection.query("SELECT users.username, SUM(results.score) FROM results JOIN users ON results.user_id = users.id GROUP BY users.username", function (err, rows1a) {
        console.log(err);
        console.log(rows1a);
        rows1 = rows1a;
        return callback(rows1);
    })
}

// Sends Individual Scores to html file
app.get("/api/data1/", function(req, res) {
    getData(function (rows1) {
        // console.log("test");
        // console.log(rows1);
        return res.json(rows1);
    });
});

// Function to collect data for SECOND Graph
function getData2(callback) {
    let rows2 = {};
    connection.query("SELECT quizzes.id, SUM(results.score) FROM results JOIN quizzes ON results.quiz_id = quizzes.id GROUP BY quizzes.id", function (err, rows2a) {
        console.log("second data");
        console.log(err);
        console.log(rows2a);
        rows2 = rows2a;
        return callback(rows2);
    })
}

  // Sends Test Values to html file
app.get("/api/data2/", function(req, res) {
    getData2(function (rows2) {
        console.log("test2");
        console.log(rows2);
        return res.json(rows2);
    });
});

// Starts the server to begin listening
// =============================================================
app.listen(PORT, function () {
    console.log("App listening on PORT " + PORT);
})

